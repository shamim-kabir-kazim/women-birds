import React from 'react';
import Admin from '../admin/Admin';


const Adminpage= () => {

  return (
    <div>
      <Admin/>
    </div>
  );
};

export default Adminpage;
