import React from 'react';
import './Sepa.css';

const Sepa = () => {
  return <div className="sepa"></div>;
};

export default Sepa;
